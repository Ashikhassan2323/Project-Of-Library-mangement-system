#include "genre.h"
#include "bookshelf.h"
#include <iostream>
using namespace std;

Genre::Genre()
{

}
Genre::Genre(string g)
{
    genreName = g;
    head = new BookShelf();
}
void Genre::addBook(Book b)
{
    head->addBook(b);
}

void Genre::sortAllBooks()
{
    head->sortBooks();
}

void Genre::searchBook(string title)
{
    int index = head->searchBook(title, 1, genreName);
    if (index == -1)
    {
        cout << "Book not found in " << genreName << " genre."<<endl;
    }
}

void Genre::displayAllBooks()
{
    cout << "\nBooks in genre: " << genreName << endl;
    head->displayBooks(1);
}

void Genre::editBookDetails(string title)
{
    int index = head->searchBook(title, 1, genreName);
    if (index != -1)
    {
        int choice;
        string newTitle, newAuthor;
        int newYear;
        double newPrice;

        do
        {
            system("cls");
    system("color 3");
            cout << endl<<"Current Book: " << head->books[index].title << " by "
                 << head->books[index].author << endl;
            cout << "1. Edit Title"<<endl;
            cout << "2. Edit Author"<<endl;
            cout << "3. Edit Year"<<endl;
            cout << "4. Edit Price"<<endl;
            cout << "5. Back"<<endl;
            cout << "Enter your choice: ";
            cin >> choice;

            if (choice == 1)
            {
                cout << "Enter new title: ";
                cin.ignore();
                getline(cin, newTitle);
                head->books[index].title = newTitle;
            }
            else if (choice == 2)
            {
                cout << "Enter new author: ";
                cin.ignore();
                getline(cin, newAuthor);
                head->books[index].author = newAuthor;
            }
            else if (choice == 3)
            {
                cout << "Enter new year: ";
                cin >> newYear;
                head->books[index].year = newYear;
            }
            else if (choice == 4)
            {
                cout << "Enter new price: ";
                cin >> newPrice;
                head->books[index].price = newPrice;
            }
            else if (choice == 5)
            {
                cout << "Going back to menu"<<endl;
            }
            else
            {
                cout << "Invalid choice. Try again"<<endl;
            }

        }
        while (choice != 5);

        cout << "Book details updated successfully."<<endl;
    }
    else
    {
        cout << "No books found in " << genreName << " genre"<<endl;
    }
}



