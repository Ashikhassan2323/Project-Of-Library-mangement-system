#include <iostream>
#include "bookshelf.h"
#include "genre.h"
#include "library.h"
#include "SplashScreen.h"
using namespace std;


int main()
{
    SplashScreen splash;
    splash.display();
    Library library;

    library.addBookToGenre({"Aronnok", "Jibonanda Das", 1890, 500}, "Fantasy");
    library.addBookToGenre({"Sherlock Holmes", "Aurther Conan Doyle", 1934, 1000}, "Mystery");
    library.addBookToGenre({"Bhuter Golpo", "Satyajit Ray", 1907, 1405}, "Horror");

    library.addBookToGenre({"Byomkesh", "Sharadindu Bandapadhay", 2005, 1050}, "Thriller");

    library.addBookToGenre({"Debdas", "Sharat Chandra Chattopadhay", 1735, 999}, "Romance");
    library.addBookToGenre({"Masud Rana", "Alif", 1969, 12}, "Crime");
    library.addBookToGenre({"Misir Ali", "Humayun Ahmed", 1951, 1199}, "Fiction");
    library.addBookToGenre({"Load Sheding", "Satyajit Ray", 1875, 1399}, "Thriller");

    int mainChoice;


    do
    {
        system("cls");
    system("color 3");

        cout  <<endl<<"1. Admin"<<endl;
        cout << "2. User"<<endl;
        cout << "3. Exit"<<endl;
        cout << "Enter your choice (1, 2, or 3): ";

        cin >> mainChoice;


        if (mainChoice == 1)
        {
            library.adminMenu();
        }
        else if (mainChoice == 2)
        {
            library.userMenu();
        }
        else if (mainChoice == 3)
        {
            cout << "Exiting program..."<<endl;
        }
        else
        {
            cout << "Invalid choice! Please enter 1, 2, or 3."<<endl;
        }

    } while (mainChoice != 3);
    return 0;
}
