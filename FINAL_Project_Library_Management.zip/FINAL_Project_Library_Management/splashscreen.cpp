#include "SplashScreen.h"
#include <iostream>
#include <chrono>
#include <thread>
#include <windows.h>
using namespace std;

void SplashScreen::display() {
   system("cls");
    system("color�2");
    cout << R"(

................................................................
.                                                              .
.                  LIBRARY MANAGEMENT SYSTEM                   .
.                                                              .
.             Developed by: Ashik * Sudad * Alif               .
.                                                              .
.           "Unlock knowledge, one page at a time."            .                                        .
.                                                              .
.                                                              .
................................................................

)";


    cout << "\nLoading";
    for (int i = 0; i < 5; ++i) {
        cout << ".";
        Sleep(400);
    }

    cout << "\nPress Enter to continue...";
    cin.get();
}





