#ifndef LIBRARY_H
#define LIBRARY_H
#include "genre.h"
#include<iostream>
using namespace std;
class Library
{
private:
    Genre fiction;
    Genre mystery;
    Genre thriller;
    Genre fantasy;
    Genre horror;
    Genre romance;
    Genre crime;

public:

    Library();
    void addBookToGenre(Book, string );
    void displayAllBooks();
    void searchBook(string );
    void adminMenu();
    void userMenu();
};

#endif�
