#ifndef GENRE_H
#define GENRE_H
#include<iostream>
using namespace std;
#include"bookshelf.h"

class Genre
{
private:
    string genreName;
    BookShelf* head;
public:

    Genre();
    Genre(string);
    void addBook(Book);
    void sortAllBooks();
    void searchBook(string);
    void displayAllBooks();
    void editBookDetails(string);
};

#endif
