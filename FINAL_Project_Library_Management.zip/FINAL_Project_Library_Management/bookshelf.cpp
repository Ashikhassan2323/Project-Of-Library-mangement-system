#include "bookshelf.h"
#include <iostream>
using namespace std;

BookShelf::BookShelf()
{
    count = 0;
    next = nullptr;
}

bool BookShelf:: isFull()
{
    return count == MAX_BOOKS;
}

void BookShelf:: addBook(Book b)
{
    if (!isFull())
    {
        books[count] = b;
        count++;
    }
    else
    {
        if (next == nullptr)
        {
            next = new BookShelf();
        }
        next->addBook(b);

    }
}

void BookShelf::sortBooks()
{

    for (int i = 0; i < count - 1; i++)
    {
        for (int j = i + 1; j < count; j++)
        {
            if (books[i].title > books[j].title)
            {
                Book temp = books[i];
                books[i] = books[j];
                books[j] = temp;
            }
        }
    }


    if (next != nullptr)
    {
        next->sortBooks();
    }
}

int BookShelf::searchBook(string title, int shelfNumber, string genreName)
{
    for (int i = 0; i < count; i++)
    {
        if (books[i].title == title)
        {
            cout << "Book found in " << genreName << " genre, Bookshelf " << shelfNumber << ":"<<endl;
            cout << "- " << books[i].title << " by " << books[i].author
                 << " (" << books[i].year << ") - Price: " << books[i].price << endl;
            return i;
        }
    }
    if (next != nullptr)
    {
        return next->searchBook(title, shelfNumber + 1, genreName);
    }
    return -1;
}

void BookShelf::displayBooks(int shelfNumber)
{
    cout << "Bookshelf " << shelfNumber << ":"<<endl;
    for (int i = 0; i < count; i++)
    {
        cout << "- " << books[i].title << " by " << books[i].author
             << " (" << books[i].year << ") - Price:"<< books[i].price<<"(BDT)"  << endl;
    }




    if(next!=nullptr)
    {
        next->displayBooks(shelfNumber+1);
    }
}
