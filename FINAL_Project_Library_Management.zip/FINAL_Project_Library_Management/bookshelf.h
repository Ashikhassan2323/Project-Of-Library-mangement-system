#ifndef BOOKSHELF_H
#define BOOKSHELF_H
#include <iostream>


using namespace std;
const int MAX_BOOKS = 3;
struct Book
{
    string title;
    string author;
    int year;
    double price;
};

class BookShelf
{
public:
    Book books[MAX_BOOKS];
    int count;
    BookShelf* next;
    BookShelf();
    bool isFull();
    void addBook(Book );
    void sortBooks();
    int searchBook(string, int, string );
    void displayBooks(int );
};

#endif
