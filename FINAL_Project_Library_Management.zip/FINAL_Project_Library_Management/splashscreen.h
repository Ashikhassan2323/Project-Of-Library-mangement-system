#ifndef SPLASHSCREEN_H
#define SPLASHSCREEN_H

class SplashScreen {
public:
    void display();
};

#endif
