#include "library.h"
#include "genre.h"
#include "bookshelf.h"
#include<iostream>
using namespace std;

Library::Library() {
    fiction = Genre("Fiction");
    mystery = Genre("Mystery");
    thriller = Genre("Thriller");
    fantasy = Genre("Fantasy");
    horror = Genre("Horror");
    romance = Genre("Romance");
    crime = Genre("Crime");
}


void Library::addBookToGenre(Book b, string genre)
{
    if (genre == "Fiction")
        fiction.addBook(b);
    else if (genre == "Mystery")
        mystery.addBook(b);
    else if (genre == "Thriller")
        thriller.addBook(b);
    else if (genre == "Fantasy")
        fantasy.addBook(b);
    else if (genre == "Horror")
        horror.addBook(b);
    else if (genre == "Romance")
        romance.addBook(b);
    else if (genre == "Crime")
        crime.addBook(b);
    else
        cout << "Invalid genre!\n";
}

void Library::displayAllBooks()
{
    fiction.displayAllBooks();
    mystery.displayAllBooks();
    thriller.displayAllBooks();
    fantasy.displayAllBooks();
    horror.displayAllBooks();
    romance.displayAllBooks();
    crime.displayAllBooks();
}

void Library::searchBook(string title)
{
    bool found = false;
    fiction.searchBook(title);
    mystery.searchBook(title);
    thriller.searchBook(title);
    fantasy.searchBook(title);
    horror.searchBook(title);
    romance.searchBook(title);
    crime.searchBook(title);
}

void Library::adminMenu()
{
    string password;
    cout << "Enter Admin password: ";
    cin >> password;

    if (password == "admin")
    {
        int choice;
        do
        {
    system("color 2");
            cout << "\nAdmin Options:"<<endl;
            cout << "1. Add Book to the Library"<<endl;
            cout << "2. Search Books by Title"<<endl;
            cout << "3. Display All Books"<<endl;
            cout << "4. Edit Book Details"<<endl;
            cout << "5. Sort All Books"<<endl;
            cout << "6. Exit"<<endl;
            cout << "Enter choice: ";
            cin >> choice;

            if (choice == 1)
            {
                string title, author, genre;
                int year;
                double price;

                cout << "Enter book title: ";
                cin.ignore();
                getline(cin, title);
                cout << "Enter author: ";
                getline(cin, author);
                cout << "Enter year: ";
                cin >> year;
                cout << "Enter price: ";
                cin >> price;
                cout << "Enter genre (Fiction, Mystery, Thriller, Fantasy, Horror, Romance, Crime): ";
                cin.ignore();
                getline(cin, genre);

                addBookToGenre({title, author, year, price}, genre);
            }
            else if (choice == 2)
            {
                string title;
                cout << "Enter the book title to search: ";
                cin.ignore();
                getline(cin, title);
                searchBook(title);
            }
            else if (choice == 3)
            {
                displayAllBooks();
            }
            else if (choice == 4)
            {
                string title;
                cout << "Enter the book title to edit: ";
                cin.ignore();
                getline(cin, title);
                fiction.editBookDetails(title);
                mystery.editBookDetails(title);
                thriller.editBookDetails(title);
                fantasy.editBookDetails(title);
                horror.editBookDetails(title);
                romance.editBookDetails(title);
                crime.editBookDetails(title);
            }
            else if (choice == 5)
            {
                fiction.sortAllBooks();
                mystery.sortAllBooks();
                thriller.sortAllBooks();
                fantasy.sortAllBooks();
                horror.sortAllBooks();
                romance.sortAllBooks();
                crime.sortAllBooks();
                cout << "All books sorted by title."<<endl;
            }
            else if (choice == 6)
            {
                cout << "Exiting Admin menu..."<<endl;
            }
            else
            {
                cout << "Invalid choice! Try again."<<endl;
            }

        }
        while (choice != 6);
    }
    else
    {
        cout << "Incorrect password. Access denied."<<endl;
    }
}

void Library::userMenu()
{
    int choice;
    do
    {

        cout << "\nUser Options:"<<endl;
        cout << "1. Search Books by Title"<<endl;
        cout << "2. Display All Books"<<endl;
        cout << "3. Exit"<<endl;
        cout << "Enter choice: ";
        cin >> choice;

        if (choice == 1)
        {
            string title;
            cout << "Enter the book title to search: ";
            cin.ignore();
            getline(cin, title);
            searchBook(title);

            int postChoice;
            do {
                cout << "\nWould you like to:"<<endl;
                cout << "1. Borrow this Book"<<endl;
                cout << "2. Return to main menu"<<endl;
                cout << "Enter choice: ";
                cin >> postChoice;

                if (postChoice == 1)
                {
                    string book;
                    int mobile,id,duration;

                    cout<<"Enter  Duration Period: "<<endl;
                    cin>>duration;
                    cout<<"Enter your ID: "<<endl;
                    cin>>id;
                    cout<<"Enter your Contact no: "<<endl;
                    cin>>mobile;
                    cout<<"Okay your information has been collected."<<endl;
                    postChoice=2;
                }
                else if (postChoice == 2)
                {
                    cout << "Returning to main menu..."<<endl;
                }
                else
                {
                    cout << "Invalid option! Try again."<<endl;
                }
            } while (postChoice != 2);
        }
        else if (choice == 2)
        {
            displayAllBooks();
            int postChoice;
            do {
                cout << "\nWould you like to:"<<endl;
                cout << "1. Borrow any Book"<<endl;
                cout << "2. Return to main menu"<<endl;
                cout << "Enter choice: ";
                cin >> postChoice;

                if (postChoice == 1)
                {
                    string book;
                    int mobile,id,duration;
                    cout << "Enter the title of the book you want to borrow: ";
                    cin.ignore();
                    getline(cin, book);
                    cout<<"Enter  Duration Period: "<<endl;
                    cin>>duration;
                    cout<<"Enter your ID: "<<endl;
                    cin>>id;
                    cout<<"Enter your Contact no: "<<endl;
                    cin>>mobile;
                    cout<<"Okay your information has been collected."<<endl;
                }
                else if (postChoice == 2)
                {
                    cout << "Returning to main menu..."<<endl;
                }
                else
                {
                    cout << "Invalid option! Try again."<<endl;
                }
            } while (postChoice != 2);
        }


        else if (choice == 3)
        {
            cout << "Exiting User menu..."<<endl;
        }
        else
        {
            cout << "Invalid choice! Try again."<<endl;
        }

    }
    while(choice!=3);
}
